"use strict"

let persona;

function saluda() {
    persona = prompt("Dime tu nombre: ", "Pablo")
    alert("Hola! " + persona);
}